# Report an Issue

## How to Report an Issue

1. Missing Words: Open an issue with [CSpell Dictionaries](https://github.com/streetsidesoftware/cspell-dicts/issues)
1. The Spell Checker is not work as expected: [Open an Issue](https://github.com/streetsidesoftware/vscode-spell-checker/issues)

[test command](command:workbench.action.closeActiveEditor)
