### Discover the Benefits of GitLens Pro

<img src="thumbnails/discover-pro.png" alt="GitLens Pro - lists GitLens Pro features" />

You also have access to the [GitKraken DevEx platform](command:gitlens.walkthrough.openDevExPlatform), unleashing powerful Git visualization & productivity capabilities everywhere you work: IDE, desktop, browser, and terminal.
